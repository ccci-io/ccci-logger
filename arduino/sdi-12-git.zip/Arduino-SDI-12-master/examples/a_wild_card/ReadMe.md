[//]: # ( @page example_a_page Example A: Using the Wildcard - Getting Single Sensor Information )
# Example A: Using the Wildcard - Getting Single Sensor Information

This is a simple demonstration of the SDI-12 library for Arduino.
It requests information about a single attached sensor, including its address and manufacturer info, and prints it to the serial port

[//]: # ( @include{lineno} a_wild_card.ino )
